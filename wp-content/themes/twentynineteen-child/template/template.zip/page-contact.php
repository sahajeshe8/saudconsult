<?php
/**
 * Template Name: Contact
 *
 */
get_header(); 
// -------------------------------------
wp_enqueue_script('script');
add_action('wp_footer','page_script',21);
function page_script(){
  ?>
  <script>



    var markers = [];

    function initialize() {
     var locations = [
     ['<div id="content-map" class="store-locator-info-window"><div id="siteNotice"></div><div id="bodyContent"> <p style="line-height:20px; width:250px"><?php the_field('map_address'); ?></p></div></div>', <?php the_field('map_latitude'); ?>, <?php the_field('map_longitude'); ?>, '<?php echo get_stylesheet_directory_uri(); ?>/images/marker.png', 1]];

     var zoom =  14;
var myLatlng = new google.maps.LatLng(25.277171,55.305573); // dubai

var mapOptions = {     

  zoom: zoom,

  zoomControl: true,

  scrollwheel: false,

  disableDefaultUI: true,
  
  center: myLatlng,  
  
  mapTypeId: google.maps.MapTypeId.ROADMAP,
  
  styles :[
  {
    "featureType": "all",
    "elementType": "labels.text.fill",
    "stylers": [
    {
      "saturation": 36
    },
    {
      "color": "#000000"
    },
    {
      "lightness": 40
    }
    ]
  },
  {
    "featureType": "all",
    "elementType": "labels.text.stroke",
    "stylers": [
    {
      "visibility": "on"
    },
    {
      "color": "#000000"
    },
    {
      "lightness": 16
    }
    ]
  },
  {
    "featureType": "all",
    "elementType": "labels.icon",
    "stylers": [
    {
      "visibility": "off"
    }
    ]
  },
  {
    "featureType": "administrative",
    "elementType": "geometry.fill",
    "stylers": [
    {
      "color": "#000000"
    },
    {
      "lightness": 20
    }
    ]
  },
  {
    "featureType": "administrative",
    "elementType": "geometry.stroke",
    "stylers": [
    {
      "color": "#000000"
    },
    {
      "lightness": 17
    },
    {
      "weight": 1.2
    }
    ]
  },
  {
    "featureType": "landscape",
    "elementType": "geometry",
    "stylers": [
    {
      "color": "#000000"
    },
    {
      "lightness": 20
    }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "geometry",
    "stylers": [
    {
      "color": "#000000"
    },
    {
      "lightness": 21
    }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry.fill",
    "stylers": [
    {
      "color": "#000000"
    },
    {
      "lightness": 17
    }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry.stroke",
    "stylers": [
    {
      "color": "#000000"
    },
    {
      "lightness": 29
    },
    {
      "weight": 0.2
    }
    ]
  },
  {
    "featureType": "road.arterial",
    "elementType": "geometry",
    "stylers": [
    {
      "color": "#000000"
    },
    {
      "lightness": 18
    }
    ]
  },
  {
    "featureType": "road.local",
    "elementType": "geometry",
    "stylers": [
    {
      "color": "#000000"
    },
    {
      "lightness": 16
    }
    ]
  },
  {
    "featureType": "transit",
    "elementType": "geometry",
    "stylers": [
    {
      "color": "#000000"
    },
    {
      "lightness": 19
    }
    ]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [
    {
      "color": "#000000"
    },
    {
      "lightness": 17
    }
    ]
  }
  ]             

};    


window.map = new google.maps.Map(document.getElementById('map'), mapOptions);

var infowindow = new google.maps.InfoWindow();

var bounds = new google.maps.LatLngBounds();

for (i = 0; i < locations.length; i++) {
  marker = new google.maps.Marker({
    position: new google.maps.LatLng(locations[i][1], locations[i][2]),
    map: map,
    icon: locations[i][3],
    animation: google.maps.Animation.DROP

  });

  bounds.extend(marker.position);

  markers.push(marker);

  google.maps.event.addListener(marker, 'click', (function (marker, i) {
    return function () {
      infowindow.setContent(locations[i][0]);
      infowindow.open(map, marker);
      jQuery('.store-locator-address').removeClass('active');
      jQuery('#address_'+i).addClass('active');
    }
  })(marker, i));
}

map.fitBounds(bounds);

var listener = google.maps.event.addListener(map, "idle", function () {
 map.setZoom(zoom);
 google.maps.event.removeListener(listener);
});

google.maps.event.addListener(infowindow,'closeclick',function(){
  jQuery('.store-locator-address').removeClass('active');
});


}




function loadScript() {
  var script = document.createElement('script');
  script.type = 'text/javascript';
  script.src = 'https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyC9RAnuHlyWPYx-3UNyx8UoeN3qG_TYrM4&' + 'callback=initialize';
  document.body.appendChild(script);
}

window.onload = loadScript;

filterInfobox = function (id) {

  jQuery('.store-locator-address').removeClass('active');
  jQuery('#address_'+id).addClass('active');

  google.maps.event.trigger(markers[id], 'click');

}


</script>
<?php
}
// -------------------------------------

if ( have_posts() ) : 
  while ( have_posts() ) :  the_post();
   $img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); 
   ?>


   <section class="contact-banner "  id="map" data-aos-delay="300" data-aos="fade-in">

   </section>

   <section class="clearfix rel pt-100 pb-100  contact-bg">
    <div class="wrap">
      <div class="form-box" data-aos-delay="300" data-aos="fade-right">
        <?php the_content(); ?>
        <div data-aos-delay="300" data-aos="fade-right">
          <?php echo do_shortcode('[contact-form-7 id="267" title="Contact Us"]'); ?>
        </div>
      </div>
      <div class="address-box" data-aos-delay="300" data-aos="fade-left">
        <h2><?php the_title(); ?></h2>
        <?php the_field('contact_opening_time'); ?>

        <ul>
          <li>
            <h3><?php _e('Locate us'); ?>:</h3>
            <span class="icn-box icon-pin-3"></span>
            <?php the_field('contact_locate'); ?>
          </li>
          <li>
            <h3><?php _e('Call us'); ?>:</h3>
            <span class="icn-box icon-call"></span>
            <?php if( have_rows('contact_call_us') ): $i = 0; ?>
              <p>
                <?php while( have_rows('contact_call_us') ): the_row(); 
                   $i = $i +1;
                  ?>
                   <?php if($i != 1){ ?><br><?php } ?><?php the_sub_field('cal_title'); ?>: <a href="tel:<?php the_sub_field('cal_phone'); ?>"><?php the_sub_field('cal_phone'); ?></a>
                  
                <?php endwhile; ?>
              </p>
            <?php endif; ?>

          </li>
          <li>
            <h3><?php _e('Email us'); ?>:</h3>
            <span class="icn-box icon-email"></span>
            <p> <a href="mailto:<?php the_field('contact_email'); ?>"><?php the_field('contact_email'); ?></a></p>
          </li>
        </ul>


      </div>
    </div>
  </section>
<?php endwhile;
endif;

get_footer(); ?>