<?php
/**
 * Template Name: Events
 *
 */
get_header(); 
// -------------------------------------
wp_enqueue_script('script');
add_action('wp_footer','page_script',21);
function page_script(){
  ?>
  <script>

  // -------script-------
  
</script>


<style>


  @media all and (min-width: 800px) {

    .fancybox-thumbs {
      top: auto;
      width: auto;
      bottom: 0;
      left: 0;
      right : 0;
      height: 95px;
      padding: 10px 10px 0 10px;
      box-sizing: border-box;
      background: rgba(0, 0, 0, 0.3);
    }

    .fancybox-show-thumbs .fancybox-inner {
      right: 0;
      bottom: 95px;
      overflow: visible;
    }

    .fancybox-thumbs::-webkit-scrollbar {
      height: 7px;
    }

    .fancybox-thumbs::-webkit-scrollbar-track {
      background: #2a2a2a;
      border-radius: 10px;
      box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
    }

    .fancybox-thumbs::-webkit-scrollbar-thumb {
      background: #ccc;
      border-radius: 10px;
    }
    .fancybox-thumbs-x .fancybox-thumbs__list{    display: inline-block;}
    .fancybox-show-thumbs .fancybox-thumbs {  text-align: center; }
    .fancybox-thumbs__list a:before{ border: 6px solid #c72236 }
  }
</style>
<?php
}
// -------------------------------------

if ( have_posts() ) : 
  while ( have_posts() ) :  the_post();
   $img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); 
   ?>


   <section class="inner-banner" style="background:  url(<?php the_field('select_banner'); ?>) center center no-repeat; background-size: cover;">
     <div class="wrap">
      <h1><?php the_title(); ?></h1>
    </div>
  </section>

  <section class="clearfix rel pt-100 pb-100" data-aos-delay="300" data-aos="fade-up">
    <div class="wrap align-left font-29">
      <div data-aos-delay="300" data-aos="fade-up" class="block-img-02"><img class="hvr-wobble-to-top-right" src="<?php echo get_stylesheet_directory_uri(); ?>/images/home-img-02.png"></div>
      <div data-aos-delay="300" data-aos="fade-up"><?php the_content(); ?></div>
    </div>
  </section>

  <section data-aos-delay="300" data-aos="fade-in" class="clearfix story-list event-list pb-100 pt-100 rel bg-gray">
   <div data-aos-delay="300" data-aos="fade-up" class="block-img-03"><img class="hvr-wobble-to-top-right" src="<?php echo get_stylesheet_directory_uri(); ?>/images/home-img-04.png"></div>
   <ul>


    <?php 


    $args = array(
      'post_type' => array( 'events' ),
      'post_status' => array( 'publish'),
      'posts_per_page' => -1,
      'order' => 'DESC',
      'orderby' => 'date',
    );

    $the_query = new WP_Query( $args );

    // The Loop
    if ( $the_query->have_posts() ) :
      ?>
      <?php while ( $the_query->have_posts() ) : $the_query->the_post(); 
        $featured_img_url = get_the_post_thumbnail_url(get_the_ID(), 'full'); 
        ?>
        <li>
          <div class="wrap">

            <div class="story-img-box" data-aos-delay="300" data-aos="fade-up">
              <div class="grid-02">

                <figure class="effect-bubba">
                  <img style="background:  url(<?php echo $featured_img_url; ?>) left bottom no-repeat; background-size: cover;"  class="res-img" src="<?php echo get_stylesheet_directory_uri(); ?>/images/image-placeholder-05.png">
                  <figcaption>




                  </figcaption>
                </figure>
              </div>  
            </div>
            <div class="story-txt-box" data-aos-delay="300" data-aos="fade-up">
              <h2><?php the_title(); ?></h2>
              <?php the_content(); ?>

              <a data-fancybox="book-consultation-<?php the_ID(); ?>" data-src="#book-consultation-<?php the_ID(); ?>" href="javascript:;"  class="but-01 black-but hvr-sweep-to-right"><?php _e('Book a consultation');?></a>

              <div id="book-consultation-<?php the_ID(); ?>" class="pop-up-text"  style="display:none;">
               <h3><?php  _e('Book a consultation'); ?></h3>
               <h2><?php the_title(); ?></h2>


               <?php echo do_shortcode('[contact-form-7 id="148" title="Event - Book a consultation"]'); ?>
             </div>
           </div>

         </div>
       </li>
       <?php
     endwhile;
   endif;

    // Reset Post Data
   wp_reset_postdata();

   ?>


 </ul>

</section>




<?php 

$images = get_field('event_gallery');

if( $images ): ?>

  <section class="clearfix pt-100 pb-100 gallery-sec align-center" data-aos-delay="300" data-aos="fade-in">
    <div class="wrap">
      <h2 data-aos-delay="300" data-aos="fade-up"><?php _e('OUR EVENTS GALLERY');?></h2>
      <ul data-aos-delay="300" data-aos="fade-in">
        <?php 
        $i =0; 
        foreach( $images as $image ): 
          $i= $i+1; 
          $imageId = $image['ID']; 
          $size = array('384', '288' ); 
          ?>

          <li data-aos-delay="300" data-aos="fade-up" <?php if($i >6 ){ ?> style="display:none;" class="content aos-init aos-animate" <?php }else{ ?>class="content"<?php } ?>>
            <div class="grid-02">

              <a  data-fancybox="gallery" href="<?php echo $image['url']; ?>"> 
                <figure class="effect-bubba">
                  <img class="res-img" src="<?php echo wp_get_attachment_image_url( $imageId, $size ); ?>">
                  <figcaption> </figcaption>
                </figure></a>
              </div></li>


            <?php endforeach; ?>
          </ul>

          <?php if( count($images) >6 ): ?><a data-aos-delay="300" data-aos="fade-up" href="javascript:void(0);" class="but-01 black-but hvr-sweep-to-right" id="loadMore"><?php _e('Load More');?></a><?php endif; ?>
        </div>
      </section>
    <?php endif; ?>


    <?php if( have_rows('consultation_panel') ): ?>
      <?php while( have_rows('consultation_panel') ): the_row(); ?>

        <section data-aos-delay="300" data-aos="fade-in" class="  min-height-01 aligh-left booking-box"  style="background:  url(<?php echo get_stylesheet_directory_uri(); ?>/images/booking-bottom-banner.jpg) center center no-repeat; background-size: cover;" >
         <div class="wrap">

           <div class="left-block">
             <h5 data-aos-delay="300" data-aos="fade-up"><?php the_sub_field('consultation_title'); ?></h5>
             <h2 data-aos-delay="300" data-aos="fade-up"><?php the_sub_field('consultation_caption'); ?></h2>
             <ul data-aos-delay="300" data-aos="fade-up">
              <li><span class="icn-box icon-call"></span> <a href="tell:<?php the_sub_field('consultation_phone_number'); ?>"><?php the_sub_field('consultation_phone_number'); ?></a></li>
              <li><span class="icn-box icon-email"></span> <a href="mailto:<?php the_sub_field('consultation_email_address'); ?>"><?php the_sub_field('consultation_email_address'); ?></a></li>

            </ul>
          </div>
          <div class="right-block">
            <a data-fancybox="book-now" data-src="#book-now" href="javascript:;"  class="but-01 black-but hvr-sweep-to-right"><?php _e('Book Now'); ?></a>
            <div id="book-now" class="pop-up-text"  style="display:none;">
              <h3><?php  _e('Book Now'); ?></h3>
              <?php echo do_shortcode('[contact-form-7 id="282" title="Events - Book Now"]'); ?>
            </div>
          </div>

        </section>

      <?php endwhile; ?>
    <?php endif; ?>


  <?php endwhile;
endif;

get_footer(); ?>


<script type="text/javascript">


  jQuery(document).ready(function(){
    jQuery(".content").slice(0, 6).show();
    jQuery("#loadMore").on("click", function(e){
      e.preventDefault();
      jQuery(".content:hidden").slice(0, 6).slideDown();
      if(jQuery(".content:hidden").length == 0) {
        jQuery("#loadMore").hide();
      }
    });

  })
</script>