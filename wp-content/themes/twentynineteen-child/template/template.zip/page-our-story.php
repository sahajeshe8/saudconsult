<?php
/**
 * Template Name: Our Story
 *
 */
get_header(); 
// -------------------------------------
wp_enqueue_script('script');
add_action('wp_footer','page_script',21);
function page_script(){
  ?>
  <script>

  // -------script-------
  
</script>
<?php
}
// -------------------------------------

if ( have_posts() ) : 
  while ( have_posts() ) :  the_post();
   $img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); 
   ?>


   <section class="inner-banner" style="background:  url(<?php the_field('select_banner'); ?>) center center no-repeat; background-size: cover;">
     <div class="wrap">
      <h1><?php the_title(); ?></h1>
    </div>
  </section>

  <section class="clearfix rel pt-100 pb-100   most-love" data-aos-delay="300" data-aos="fade-in">
    <div class="wrap align-left">
      <div data-aos-delay="300" data-aos="fade-left" class="block-img-01"><img class="hvr-wobble-to-top-right"  src="<?php echo get_stylesheet_directory_uri(); ?>/images/home-img-02.png"></div>
      <div data-aos-delay="300" data-aos="fade-up"><?php the_content(); ?></div>
    </div>
  </section>


  <?php if( have_rows('add_stories') ): ?>
    <section class="clearfix story-list pb-100">
      <ul>
        <?php while( have_rows('add_stories') ): the_row(); 
          $story_title = get_sub_field('story_title');
          $story_image = get_sub_field('story_image');
          $story_short_description = get_sub_field('story_short_description');
          ?>
          
          <li>
            <div class="wrap">

              <div class="story-img-box" data-aos-delay="300" data-aos="fade-right">
                <div class="grid-02">

                  <figure class="effect-bubba">
                    <img style="background:  url(<?php echo $story_image; ?>) left bottom no-repeat; background-size: cover;"  class="res-img desk-non-01" src="<?php echo get_stylesheet_directory_uri(); ?>/images/image-placeholder-03.png">
                    <figcaption>

                    </figcaption>
                  </figure>
                </div>
              </div>
              <div class="story-txt-box" data-aos-delay="300" data-aos="fade-left">
                <h2><?php echo $story_title; ?></h2>
                <?php echo $story_short_description; ?>
              </div>

            </div>
          </li>
        <?php endwhile; ?>
      </ul>
    </section>
  <?php endif; ?>

  <section data-aos-delay="300" data-aos="fade-in" class="block-01 min-height-01"  style="background:  url(<?php the_field('contact_banner'); ?>) center center no-repeat; background-size: cover;" >
   <div class="wrap">
    <h2 data-aos-delay="300" data-aos="fade-up"><?php the_field('contact_title'); ?></h2>
    <a data-aos-delay="300" data-aos="fade-up" href="<?php if(get_field('contact_banner') == ''){ echo "#."; }else{ echo the_field('contact_link'); } ?>" class="but-01 hvr-sweep-to-right"><?php _e('Contact Us'); ?></a>
  </div>
</section>

<?php endwhile;
endif;

get_footer(); ?>