<?php
/**
 * Template Name: Our Services
 *
 */
get_header(); 
// -------------------------------------
wp_enqueue_script('script');
add_action('wp_footer','page_script',21);
function page_script(){
  ?>
  <script>

  // -------script-------
  
</script>
<?php
}
// -------------------------------------

if ( have_posts() ) : 
  while ( have_posts() ) :  the_post();
   $img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); 
   ?>


   <section class="inner-banner" style="background:  url(<?php the_field('select_banner'); ?>) center center no-repeat; background-size: cover;">
     <div class="wrap">
      <h1><?php the_title(); ?></h1>
    </div>
  </section>

  <section class="clearfix rel pt-100 pb-100  ">
    <div class="wrap align-left font-29" data-aos-delay="300" data-aos="fade-up">
      <div data-aos-delay="300" data-aos="fade-left" class="block-img-03 right-04 "><img class="hvr-wobble-to-top-right" src="<?php echo get_stylesheet_directory_uri(); ?>/images/home-img-02.png"></div>
      <?php the_content(); ?>
    </div>
  </section>




  <?php if( have_rows('add_services') ): ?>
    <section class="clearfix story-list services-list pb-100">
      <ul>
        <?php while( have_rows('add_services') ): the_row(); 
          $services_title = get_sub_field('services_title');
          $services_image = get_sub_field('services_image');
          $services_short_description = get_sub_field('services_short_description');
          ?>
          
          <li>
            <div class="wrap">

              <div class="story-img-box" data-aos-delay="300" data-aos="fade-right">
                <div class="grid-02">

                  <figure class="effect-bubba">
                    <img style="background:  url(<?php echo $services_image; ?>) left bottom no-repeat; background-size: cover;"  class="res-img desk-non-01" src="<?php echo get_stylesheet_directory_uri(); ?>/images/image-placeholder-03.png">
                    <figcaption>

                    </figcaption>
                  </figure>
                </div>
              </div>
              <div class="story-txt-box" data-aos-delay="300" data-aos="fade-left">
                <h2><?php echo $services_title; ?></h2>
                <?php echo $services_short_description; ?>
                <?php if(get_sub_field('services_consultation_button') == 1){ ?>
                  <a data-fancybox="book-consultation-<?php the_ID(); ?>" data-src="#book-consultation-<?php the_ID(); ?>" href="javascript:;" class="but-01 black-but hvr-sweep-to-right"><?php _e('Book a consultation'); ?></a>

                  <div id="book-consultation-<?php the_ID(); ?>" class="pop-up-text"  style="display:none;">
                   <h3><?php  _e('Book a consultation'); ?></h3>
                   <h2><?php the_title(); ?></h2>


                   <?php echo do_shortcode('[contact-form-7 id="613" title="Services- Book a consultation"]'); ?>
                 </div>

               <?php } ?>
             </div>

           </div>
         </li>
       <?php endwhile; ?>
     </ul>
   </section>
 <?php endif; ?>

 <?php if( have_rows('consultation_panel') ): ?>
  <?php while( have_rows('consultation_panel') ): the_row(); ?>

    <section data-aos-delay="300" data-aos="fade-in" class="  min-height-01 aligh-left booking-box"  style="background:  url(<?php echo get_stylesheet_directory_uri(); ?>/images/booking-bottom-banner.jpg) center center no-repeat; background-size: cover;" >
     <div class="wrap">

       <div class="left-block">
         <h5 data-aos-delay="300" data-aos="fade-up"><?php the_sub_field('consultation_title'); ?></h5>
         <h2 data-aos-delay="300" data-aos="fade-up"><?php the_sub_field('consultation_caption'); ?></h2>
         <ul data-aos-delay="300" data-aos="fade-up">
          <li> <a href="tell:<?php the_sub_field('consultation_phone_number'); ?>"><?php the_sub_field('consultation_phone_number'); ?></a></li>
          <li> <a href="mailto:<?php the_sub_field('consultation_email_address'); ?>"><?php the_sub_field('consultation_email_address'); ?></a></li>

        </ul>
      </div>
      <div class="right-block">
       <a data-fancybox="book-now" data-src="#book-now" href="javascript:;"  class="but-01 black-but hvr-sweep-to-right"><?php _e('Book Now'); ?></a>
       <div id="book-now" class="pop-up-text"  style="display:none;">
         <h3><?php  _e('Book a consultation'); ?></h3>
         <?php echo do_shortcode('[contact-form-7 id="282" title="Book Now"]'); ?>
       </div>
     </div>
   </div>

 </section>

<?php endwhile; ?>
<?php endif; ?>
</script>

<?php endwhile;
endif;

get_footer(); ?>