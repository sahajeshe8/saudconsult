<?php
/**
 * Template Name: Workshops
 *
 */
get_header(); 
// -------------------------------------
wp_enqueue_script('fancybox');
add_action('wp_footer','page_script',21);
function page_script(){
  ?>
  <script>

  // -------script-------
  
</script>


<style>


  @media all and (min-width: 800px) {

    .fancybox-thumbs {
      top: auto;
      width: auto;
      bottom: 0;
      left: 0;
      right : 0;
      height: 95px;
      padding: 10px 10px 0 10px;
      box-sizing: border-box;
      background: rgba(0, 0, 0, 0.3);
    }

    .fancybox-show-thumbs .fancybox-inner {
      right: 0;
      bottom: 95px;
      overflow: visible;
    }

    .fancybox-thumbs::-webkit-scrollbar {
      height: 7px;
    }

    .fancybox-thumbs::-webkit-scrollbar-track {
      background: #2a2a2a;
      border-radius: 10px;
      box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
    }

    .fancybox-thumbs::-webkit-scrollbar-thumb {
      background: #ccc;
      border-radius: 10px;
    }
    .fancybox-thumbs-x .fancybox-thumbs__list{    display: inline-block;}
    .fancybox-show-thumbs .fancybox-thumbs {  text-align: center; }
    .fancybox-thumbs__list a:before{ border: 6px solid #ff5268 }
  }
</style>
<?php
}
// -------------------------------------

if ( have_posts() ) : 
  while ( have_posts() ) :  the_post();
   $img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); 
   ?>


   <section class="inner-banner" style="background:  url(<?php the_field('select_banner'); ?>) center center no-repeat; background-size: cover;">
     <div class="wrap">
      <h1><?php the_title(); ?></h1>
      <?php the_content(); ?>
    </div>
  </section>



  <?php 


  $args = array(
    'post_type' => array( 'workshops' ),
    'post_status' => array( 'publish'),
    'posts_per_page' => -1,
    'order' => 'DESC',
    'orderby' => 'date',
  );

  $the_query = new WP_Query( $args );

    // The Loop
  if ( $the_query->have_posts() ) :
    ?>
    <?php while ( $the_query->have_posts() ) : $the_query->the_post(); 
      $featured_img_url = get_the_post_thumbnail_url(get_the_ID(), 'full'); 
      ?>

      <section class="pt-100 pb-100 rel workshop-main">
       <div data-aos-delay="300" data-aos="fade-left" class="home-img-01"><img class="hvr-wobble-to-top-right"  src="<?php echo get_stylesheet_directory_uri(); ?>/images/home-img-02.png"></div>

       <div data-aos-delay="300" data-aos="fade-right" class="home-img-04"><img class="hvr-wobble-to-top-right" src="<?php echo get_stylesheet_directory_uri(); ?>/images/home-img-01.png"></div>
       <div class="wrap flx-box">
        <div class="work-shop-left-box" data-aos-delay="300" data-aos="fade-right">

          <div class="grid-02">

            <figure class="effect-bubba">
              <img src="<?php  echo get_the_post_thumbnail_url( get_the_ID(),array(550, 821) );  ?>">
              <figcaption>

              </figcaption>
            </figure>
          </div>
        </div>
        <div class="work-shop-right-box" data-aos-delay="300" data-aos="fade-left">

         <h4><?php the_field('workshop_date'); ?></h4>
         <ul class="post-info" >

          <?php if( have_rows('workshop_time') ): ?>
            <?php while( have_rows('workshop_time') ): the_row(); 
              ?>
              <li><p><?php the_sub_field('workshop_start_time'); ?> - <?php the_sub_field('workshop_end_time'); ?></p></li>

            <?php endwhile; ?>
          <?php endif;  ?>
          <li><p><?php if(get_field('workshop_payment') == 1){ _e('Free'); }else{ echo 'AED '.get_field('workshop_amount').'/-'; } ?></p></li>

        </ul>
        <h3><?php the_title(); ?></h3>
        <?php the_content(); ?>
        <a data-fancybox="view-detail-<?php the_ID(); ?>" data-src="#view-detail-<?php the_ID(); ?>" href="javascript:;" class="but-01 black-but hvr-sweep-to-right"><?php  _e('View Details'); ?></a>
        <a data-fancybox="book-consultation-<?php the_ID(); ?>" data-src="#book-consultation-<?php the_ID(); ?>" href="javascript:;" class="but-01 black-but hvr-sweep-to-right"><?php  _e('Book a consultation'); ?></a>
      </div>
    </div>
    <div class="home-img-02"><img  class="hvr-wobble-to-top-right" src="<?php echo get_stylesheet_directory_uri(); ?>/images/home-img-04.png"></div>	  
    <div id="book-consultation-<?php the_ID(); ?>" class="pop-up-text"  style="display:none;">
     <h3><?php  _e('Book a consultation'); ?></h3>
     <h2><?php the_title(); ?></h2>
     <h4><?php the_field('workshop_date'); ?></h4>
     <ul class="post-info">
       <?php if( have_rows('workshop_time') ): ?>
         <?php while( have_rows('workshop_time') ): the_row(); 
          ?>
          <li><p><?php the_sub_field('workshop_start_time'); ?> - <?php the_sub_field('workshop_end_time'); ?></p></li>

        <?php endwhile; ?>
      <?php endif;  ?>
      <li><p><?php if(get_field('workshop_payment') == 1){ _e('Free'); }else{ echo 'AED '.get_field('workshop_amount').'/-'; } ?></p></li>

    </ul>
    
    <?php echo do_shortcode('[contact-form-7 id="148" title="Book a consultation"]'); ?>
  </div>

  <div id="view-detail-<?php the_ID(); ?>" class="pop-up-text" style="display: none;width:100%;max-width:1170px;">

    <img class="res-img" src="<?php echo get_stylesheet_directory_uri(); ?>/images/workshops-detail-img.jpg">

    <h3><?php the_title(); ?></h3>

    <h4><?php the_field('workshop_date'); ?></h4>
    <ul class="post-info">
      <?php if( have_rows('workshop_time') ): ?>
        <?php while( have_rows('workshop_time') ): the_row(); 
          ?>
          <li><p><?php the_sub_field('workshop_start_time'); ?> - <?php the_sub_field('workshop_end_time'); ?></p></li>

        <?php endwhile; ?>
      <?php endif;  ?>
      <li><p><?php if(get_field('workshop_payment') == 1){ _e('Free'); }else{ echo 'AED '.get_field('workshop_amount').'/-'; } ?></p></li>

    </ul>
    <?php the_content(); ?>

    <h5><?php  _e('Location & Contact Details'); ?></h5>
    <ul>

      <li>
       <span class="icn-box icon-call"></span>
       <p> <a href="tel:<?php the_field('contact_phone_number'); ?>"><?php the_field('contact_phone_number'); ?></a> 
       </p>
     </li>

     <li>
      <span class="icn-box icon-email"></span>
      <p> <a href="<?php the_field('contact_email_address'); ?>"><?php the_field('contact_email_address'); ?></a></p>
    </li>
    <li>

     <span class="icn-box icon-pin-3"></span>
     <p><?php the_field('contact_location_details'); ?></p>
   </li>
 </ul>
 <a data-fancybox="pop-book-consultation-<?php the_ID(); ?>" data-src="#book-consultation-<?php the_ID(); ?>" href="javascript:;" class="but-01 black-but hvr-sweep-to-right"><?php  _e('Book Now'); ?></a>
</div>


</section>

<?php endwhile; ?>

<?php endif;

    // Reset Post Data
wp_reset_postdata();

?>




<?php if( have_rows('workshop_panel') ): ?>
  <?php while( have_rows('workshop_panel') ): the_row(); ?>

    <section data-aos-delay="300" data-aos="fade-in" class="  min-height-01  booking-box flx-center"  style="background:  url(<?php echo get_stylesheet_directory_uri(); ?>/images/booking-bottom-banner.jpg) center center no-repeat; background-size: cover;" >
     <div class="wrap">



      <h2 data-aos-delay="300" data-aos="fade-up"><?php the_sub_field('workshop_title'); ?></h2>
      <p data-aos-delay="300" data-aos="fade-up"><?php the_sub_field('workshop_caption'); ?></p>

      <a data-fancybox="book-now" data-src="#book-now" href="javascript:;"  class="but-01 black-but hvr-sweep-to-right"><?php _e('Book Now'); ?></a>
      <div id="book-now" class="pop-up-text"  style="display:none;">
       <h3><?php  _e('Book Now'); ?></h3>
       <?php echo do_shortcode('[contact-form-7 id="502" title="Workshop - Book Now"]'); ?>
     </div>
   </a>


 </section>

<?php endwhile; ?>

<?php endif;  ?>
<?php 

$images = get_field('workshop_gallery');

if( $images ): ?>

  <section class="clearfix pt-100 pb-100 gallery-sec align-center" data-aos-delay="300" data-aos="fade-in">
    <div class="wrap">
      <h2 data-aos-delay="300" data-aos="fade-up"><?php _e('OUR WORKSHOPS GALLERY'); ?></h2>
      <ul data-aos-delay="300" data-aos="fade-up">
        <?php $i =0; foreach( $images as $image ): 
        $i= $i+1;
        $imageId = $image['ID']; 
        $size = array('384', '288' );  ?>

        <li data-aos-delay="300" data-aos="fade-up"  <?php if($i >6 ){ ?> style="display:none;" class="content aos-init aos-animate" <?php }else{ ?>class="content"<?php } ?>>
          <div class="grid-02">

            <a  data-fancybox="gallery" href="<?php echo $image['url']; ?>" > 
              <figure class="effect-bubba">
                <img class="res-img" src="<?php echo wp_get_attachment_image_url( $imageId, $size ); ?>">
                <figcaption> </figcaption>
              </figure></a>
            </div>
          </li>


        <?php endforeach; ?>
      </ul>

      <?php if( count($images) >6 ): ?> <a data-aos-delay="300" data-aos="fade-up" href="javascript:void(0);" class="but-01 black-but hvr-sweep-to-right" id="loadMore"><?php _e('Load More'); ?></a><?php endif; ?>
    </div>
  </section>
<?php endif; ?>

<?php endwhile;
endif;

get_footer(); ?>



<script type="text/javascript">


  jQuery(document).ready(function(){
    jQuery(".content").slice(0, 6).show();
    jQuery("#loadMore").on("click", function(e){
      e.preventDefault();
      jQuery(".content:hidden").slice(0, 6).slideDown();
      if(jQuery(".content:hidden").length == 0) {
        jQuery("#loadMore").hide();
      }
    });

  })
</script>